import * as React from "react";
import {Currency as CurrencyEntity} from './Currency';
import {CurrencyFormButtonType, CurrencyInterface} from './types';

interface CurrencyFormProps {
    currency?: CurrencyEntity;
    buttonClick: (Currency: CurrencyEntity) => void;
    buttonType: CurrencyFormButtonType;
    cancelClick: () => void;
}

export class CurrencyForm extends React.Component<CurrencyFormProps, Partial<CurrencyInterface>> {
    constructor(props: CurrencyFormProps) {
        super(props);
        this.onTextChange = this.onTextChange.bind(this);
        this.buttonClick = this.buttonClick.bind(this);
        this.state = {
            currency: props.currency ? { ...props.currency } : { Id: '', Name: '', IsoCode: '', Rates: [] }
        }
    }

    buttonClick(evt: React.MouseEvent<HTMLButtonElement>) {
        evt.preventDefault();
        //this.props.buttonClick(this.state.currency);
    }

    componentWillReceiveProps(props: CurrencyFormProps) {
        this.setState({ currency: props.currency ? { ...props.currency } : { Id: '', Name: '', IsoCode: '', Rates: [] } });
    }

    onTextChange(e: any) {
        let currency: any = this.state.currency;
        currency[e.target.name] = e.target.value;
        this.setState({ currency });
    }

    render() {
        return (
            <form>
                <input className='form-control'
                    name='firstName'
                    onChange={this.onTextChange}
                    type='text'
                    value={this.state.currency!.Id} />
                <input className='form-control'
                    name='firstName'
                    onChange={this.onTextChange}
                    type='text'
                    value={this.state.currency!.IsoCode} />
                <input className='form-control'
                    name='firstName'
                    onChange={this.onTextChange}
                    type='text'
                    value={this.state.currency!.Name} />
                <button
                    className={this.props.buttonType == 'edit' ? 'btn btn-success' : 'btn btn-primary'}
                    onClick={this.buttonClick}
                >
                    {this.props.buttonType == 'edit' ? 'Update' : 'Add'}
                </button>
                <button type='button'
                    className='btn btn-danger'
                    onClick={this.props.cancelClick}
                >
                    Cancel
                </button>
            </form>
        )
    }
}
